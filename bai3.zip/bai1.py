# Yêu cầu người dùng nhập vào một số nguyên dương
n = int(input("Nhập vào một số nguyên dương: "))

# Kiểm tra chia hết cho 2
if n % 2 == 0:
    print("Đây là một số chẵn")
else:
    print("Đây là một số lẻ")