print("1. Bài 1")
print("2. Bài 2")
print("3. Bài 3")
print("4. Bài 4")

chon = int(input("Chọn bài: "))

if chon == 1:
    i = 1
    tich = 1
    while i <= 10:
        tich *= i
        i += 1
    print("Tích =", tich)

elif chon == 2:
    n = int(input("Nhập n: "))
    i = 1
    gt = 1
    while i <= n:
        gt *= i
        i += 1
    print(f"{n}! =", gt)

elif chon == 3:
    n = int(input("Nhập n: "))
    if n < 2:
        print("Không phải số nguyên tố")
    else:
        i = 2
        kt = True
        while i <= n // 2:
            if n % i == 0:
                kt = False
                break
            i += 1
        if kt:
            print("Đây là số nguyên tố")
        else:
            print("Không phải số nguyên tố")

elif chon == 4:
    n = int(input("Nhập n: "))
    i = 1
    tong = 0
    while i < n:
        if i % 2 == 0:
            tong += i
        i += 1
    print("Tổng =", tong)

else:
    print("Chọn sai!")